<?php
	notify('对接Token');
	/**
    * @Note                   支付回调
    * @param @key             对接Token
    * @param @data            返回的数据， 可以用$_REQUEST获取
    * @param @id              对接ID
    * @param @out_trade_no    发起订单号
    * @param @money           金额（元）
    * @param @trade_status    TRADE_SUCCESS or TRADE_FAIL
    */
    
    function notify($key)
    {
        $data['id'] = $_REQUEST['id']; 
		$data['trade_no'] = $_REQUEST['trade_no'];
		$data['out_trade_no'] = $_REQUEST['out_trade_no']; 
		$data['name'] = $_REQUEST['name']; 
		$data['money'] = $_REQUEST['money']; 
		$data['trade_status'] = $_REQUEST['trade_status']; 

		@$data = get_magic_quotes_gpc() ? stripslashes(array_filter($data)) : array_filter($data);
		ksort($data);
		$str1 = '';
		foreach ($data as $k => $v) {
		$str1 .= '&' . $k . "=" . $v;
		}
		$sign = md5(trim($str1 . $key, '&'));
		if ($sign !== $_REQUEST['sign']) {
			//doFailAction(); 失败， 失败逻辑处理
			echo 'fail';
			exit;
		} else {
			//doSuccessAction(); 成功， 成功逻辑处理
			echo 'success';
		}
     }

?>