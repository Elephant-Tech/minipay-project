<?php
//DEMO VERSION - V1.02
//UPDATE - 20210131
header("Content-type:text/html;charset=utf-8");
//可以选择用submit.php提交到当前文件，优化客户支付体验。也可以直接进行支付提交。
create_pay('0', '0', '0',$_GET['out_trade_no'],$_GET['name'],$_GET['price'],$_GET['notify_url'],$_GET['bank_url'], $_GET['user_agent']);

/**
 * @Note  发起支付
 * @param @id             对接UID
 * @param @key            对接Token
 * @param @type           914 QQ华夏通道,915 DNF通道,917 QQ三国通道， 918 天涯明月刀,  919 捕鱼来了微信,  920 剑灵,  921 王者荣耀QQ区,  922 上古世纪
 * @param @trade_no       订单号
 * @param @name           商品名称
 * @param @money          金额（元）
 * @param @notify_url     异步通知地址
 * @param @return_url     同步支付地址（支付成功后跳转的页面）
 * @param @mchid          商户id (如果为空,则随机选择支付商户)
 */
function create_pay($id, $key, $type, $trade_no, $name, $money, $notify_url, $return_url, $user_agent, $mchid = '')
{
    $url = '【请联系客服索取】';
    $data = [
        'id' => $id,
        'out_trade_no' => $trade_no,
        'name' => $name,
        'type' => $type,
        'money' => $money,
        'mchid' => $mchid,
        'notify_url' => $notify_url,
        'return_url' => $return_url,
		'user_agent' => $user_agent, //20201207 获取用户UA 适应后台的自适应按钮 前端通过$_SERVER['HTTP_USER_AGENT']获取后传入
		'requestip'  => $_SERVER['REMOTE_ADDR']
    ];

    $data = array_filter($data);
    if (@get_magic_quotes_gpc()) {
        $data = stripslashes($data);
    }
    ksort($data);
    $str1 = '';
    foreach ($data as $k => $v) {
        $str1 .= '&' . $k . "=" . $v;
    }

    $sign = md5(trim($str1 . $key, '&'));

    $data['sign'] = $sign;
    $data['sign_type'] = 'MD5';
	if ( $type == 913) {
        $info = posturl( $url, $data );
        if ( $info['code'] == 0 ) {
            echo $info['message'];
            exit;
        }
        $info = $info['data'];
        $root_path = 'http://'.$_SERVER['HTTP_HOST'].'/happypay/media/huya_pay.php?user_order_num=' . $info['user_order_num'] . '&uid=' . $info['uid']
        . '&pay_url=' . $info['pay_url']. '&return_url=' . $info['return_url']. '&goods_name=' . $info['goods_name']. '&money=' . $info['money'].'&host='.'http://'.$_SERVER['HTTP_HOST'];
        echo "<script>location.href='$root_path';</script>";
    } else if($type == 914 || $type == 915 || $type == 917 || $type == 918|| $type == 919|| $type == 920|| $type == 921|| $type == 922|| $type == 923){
        $info = posturl($url, $data);
        if($info['code']==0){
            echo $info['message'];
            exit;
        }
		$info = $info['data'];
        if($info['pay_type']==1){
            $root_path='http://'.$_SERVER['HTTP_HOST'].'/happypay/media/tencenth5_pay.php?store_name=' . $info['store_name'] . '&goods_name=' . $info['goods_name'] . '&uid=' . $info['uid'] . '&pay_url=' . $info['pay_url']. '&return_url=' . $info['return_url']. '&user_order_num=' . $info['user_order_num']
            . '&money=' . $info['money'];
        }else{
            $root_path='http://'.$_SERVER['HTTP_HOST'].'/happypay/media/tencentqr_pay.php?store_name=' . $info['store_name'] . '&goods_name=' . $info['goods_name'] . '&uid=' . $info['uid'] . '&pay_url=' . $info['pay_url']. '&return_url=' . $info['return_url']. '&user_order_num=' . $info['user_order_num']
            . '&money=' . $info['money'];
        }
        echo "<script>location.href='$root_path';</script>";
    }elseif ($type == 916) {
        $info = posturl( $url, $data );
        if ( $info['code'] == 0 ) {
            echo $info['message'];
            exit;
        }
        $info = $info['data'];
        $root_path = 'http://'.$_SERVER['HTTP_HOST'].'/happypay/media/mhxy_pay.php?user_order_num=' . $info['user_order_num'] . '&uid=' . $info['uid']
        . '&pay_url=' . $info['pay_url']. '&return_url=' . $info['return_url']. '&goods_name=' . $info['goods_name']. '&money=' . $info['money'].'&host='.'http://'.$_SERVER['HTTP_HOST'];
        echo "<script>location.href='$root_path';</script>";
    }else {
		$htmls = "<form id='happypay' name='happypay' action='" . $url . "' method='post'>";
        foreach ($data as $key => $val) {
            $htmls .= "<input type='hidden' name='" . $key . "' value='" . $val . "'/>";
        }
        $htmls .= "</form>";
        $htmls .= "<script>document.forms['happypay'].submit();</script>";
        exit($htmls);
    }
}

//支付方法内使用，客户不需要调用！
function posturl($url, $data)
{
    $data = json_encode($data);
    $headerArray = array("Content-type:application/json;charset='utf-8'", "Accept:application/json");
    $curl = curl_init();
    curl_setopt($curl, CURLOPT_URL, $url);
    curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, FALSE);
    curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, FALSE);
    curl_setopt($curl, CURLOPT_POST, 1);
    curl_setopt($curl, CURLOPT_POSTFIELDS, $data);
    curl_setopt($curl, CURLOPT_HTTPHEADER, $headerArray);
    curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
    $output = curl_exec($curl);
    curl_close($curl);
    return json_decode($output, true);
}

?>